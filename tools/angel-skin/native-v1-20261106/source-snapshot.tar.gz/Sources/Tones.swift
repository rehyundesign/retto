// 상태를 뜻 단위 색 넷으로 줄인 팔레트와 상태별 애니메이션.

import AppKit
import CoreText
import Foundation

// 여기에 "쉬는 중"만 무채색으로 하나 더 둔다. 색이 없어야 조용한 상태로 읽힌다.
func hexColor(_ value: UInt32) -> NSColor {
    NSColor(
        calibratedRed: CGFloat((value >> 16) & 0xFF) / 255,
        green: CGFloat((value >> 8) & 0xFF) / 255,
        blue: CGFloat(value & 0xFF) / 255,
        alpha: 1
    )
}

/// 레토가 누구인지. 화면 여러 곳에서 같은 값을 써야 해서 여기 모아 둔다.
enum Retto {
    /// 영어 표기는 t 를 둘 쓴다.
    static let englishName = "Retto"
    static let koreanName = "레토"
    static let character = "luxia yoon 의 랙돌 고양이"
    static let creator = "luxia yoon"
    static let email = "ydh3600@gmail.com"
    static let linkedIn = "https://www.linkedin.com/in/donghyunyoon/"

    /// 실제 고양이의 신상. 화면 여러 곳에서 같은 값을 써야 하니 여기 한 벌만 둔다.
    static let breed = "랙돌"
    static let sex = "수컷"
    static let birthday = DateComponents(year: 2026, month: 2, day: 11)
    static let birthdayLabel = "2026년 2월 11일"

    /// 오늘 기준 나이. 돌 전에는 개월로만 센다 — 아직 그럴 나이다.
    static var ageLabel: String {
        let calendar = Calendar.current
        guard let born = calendar.date(from: birthday) else { return "" }
        let parts = calendar.dateComponents([.year, .month], from: born, to: Date())
        let years = max(0, parts.year ?? 0)
        let months = max(0, parts.month ?? 0)
        if years == 0 { return "\(months)개월" }
        if months == 0 { return "\(years)살" }
        return "\(years)살 \(months)개월"
    }

    /// 언제·어떤 커밋으로 만든 빌드인지. 같은 버전을 여러 번 보내도 이걸로 가른다.
    /// build.sh 가 번들 Info.plist 에만 찍으므로, 없으면 빈 문자열이다.
    static var buildStamp: String {
        Bundle.main.infoDictionary?["RettoBuildStamp"] as? String ?? ""
    }

    static var version: String {
        let short = Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "?"
        let build = Bundle.main.infoDictionary?["CFBundleVersion"] as? String ?? "?"
        return short + " (" + build + ")"
    }
}

struct StatusTone {
    let key: String
    let background: NSColor
    let text: NSColor
}

// 이름표는 열두 자짜리 작은 글자다. 그래서 큰 글자 기준(3:1)이 아니라 본문 기준 4.5:1 을 지킨다.
// 예전에는 완료 2.77, 문제 3.44, 쉬는 중 3.74, 내 답 대기 3.62 로 전부 모자랐다.
//
// 배경 밝기에 따라 글자색을 정한다 — 밝은 배경(초록·주황)은 어두운 글자, 깊은 배경은 흰 글자.
// 초록이 이미 그렇게 쓰고 있었고, 그 밝기비(0.29)를 주황에도 그대로 적용했다.
// 주황은 배경을 어둡게 하지 않고 글자만 낮췄다 — 배지로도 쓰는 색이라 눈에 띄는 것이 먼저다.
// 나머지 셋은 배경만 한 단계 낮춰 지금 인상을 지켰다(밝기 87~89%, 문제는 77%).
let toneWorking = StatusTone(key: "working", background: hexColor(0x73DF5D), text: hexColor(0x0A5225))   // 5.54:1
let toneNeedsYou = StatusTone(key: "needsYou", background: hexColor(0x0174E3), text: hexColor(0xFFFFFF)) // 4.56:1
let toneDone = StatusTone(key: "done", background: hexColor(0xF06200), text: hexColor(0x441C00))         // 4.57:1
let toneFailed = StatusTone(key: "failed", background: hexColor(0xDC0714), text: hexColor(0xFFF499))     // 4.57:1
let toneQuiet = StatusTone(key: "quiet", background: hexColor(0x757575), text: hexColor(0xFFFFFF))       // 4.61:1

let toneSlack = StatusTone(key: "slack", background: hexColor(0x7C3AED), text: hexColor(0xFFFFFF))

func notificationTone(source: String?, state: PetState, fallback: StatusTone) -> StatusTone {
    if source == "slack" && state == .waving { return toneSlack }
    if state == .failed { return toneFailed }
    return fallback
}

struct Animation {
    let row: Int
    let frames: Int
    let interval: TimeInterval
    let cycleLimit: Int?
    let kicker: String
    let title: String
    let tone: StatusTone
}

/// 끌 때 끌리는 방향으로 달린다 — 코덱스 펫과 같은 반응이다.
/// 상태가 아니라 조작에 대한 반응이라 animationCatalog 에 넣지 않는다.
/// 말풍선·이름표·우선순위는 끄는 동안에도 실제 상태를 그대로 쓴다.
/// 행 2 는 행 1 을 좌우로 뒤집어 만든 것이다 — 원본 행 2 는 얼굴이 칸 밖으로 잘려 있었다.
let dragRunAnimations: [DragRun: Animation] = [
    .right: Animation(row: 1, frames: 8, interval: 0.085, cycleLimit: nil, kicker: "RUN", title: "따라가는 중", tone: toneWorking),
    .left:  Animation(row: 2, frames: 8, interval: 0.085, cycleLimit: nil, kicker: "RUN", title: "따라가는 중", tone: toneWorking),
]

let animationCatalog: [PetState: Animation] = [
    .idle: Animation(row: 0, frames: 6, interval: 0.23, cycleLimit: nil, kicker: "RESTING", title: "조용히 곁을 지키는 중", tone: toneQuiet),
    // 매지컬 하트의 진행 중 행은 8프레임 변신 연출을 2초에 한 바퀴 돌린다.
    .running: Animation(row: 7, frames: 8, interval: 0.25, cycleLimit: nil, kicker: "THINKING", title: "AI가 생각중…", tone: toneWorking),
    .review: Animation(row: 8, frames: 6, interval: 0.155, cycleLimit: nil, kicker: "USING A TOOL", title: "도구를 쓰는 중", tone: toneWorking),
    .waiting: Animation(row: 6, frames: 6, interval: 0.31, cycleLimit: nil, kicker: "NEEDS YOU", title: "네 결정을 기다리는 중", tone: toneNeedsYou),
    .failed: Animation(row: 5, frames: 8, interval: 0.18, cycleLimit: nil, kicker: "OOPS", title: "잠깐 발이 꼬였어", tone: toneFailed),
    .waving: Animation(row: 3, frames: 4, interval: 0.185, cycleLimit: 2, kicker: "DONE", title: "다 했어! 잘했어", tone: toneDone),
    .jumping: Animation(row: 4, frames: 5, interval: 0.15, cycleLimit: nil, kicker: "LET'S GO", title: "시작해 볼까?", tone: toneWorking),
    // 행 11 은 누워 자는 레토의 한 호흡이다. 얼굴·발·바닥선은 고정하고
    // 등과 흉곽만 올라갔다 내려오며, 여섯 프레임이 약 2.76초에 한 번 돈다.
    .sleeping: Animation(row: 11, frames: 6, interval: 0.46, cycleLimit: nil, kicker: "ZZZ", title: "쿨쿨 자는 중", tone: toneQuiet)
]

/// 메뉴에서 고르는 값. `auto` 는 훅이 세션마다 적어 둔 클라이언트를 따른다.
/// Codex 세션은 Codex 앱으로만 열 수 있어서 이 선택과 무관하게 Codex 로 간다.
/// 이 값은 Claude Code 세션을 VS Code 와 Claude 앱 중 어디서 열지 정한다.
enum OpenTarget: String, CaseIterable {
    case auto
    case vscode
    case claude

    var label: String {
        switch self {
        case .auto: return "자동 · 세션이 시작된 곳"
        case .vscode: return "VS Code"
        case .claude: return "Claude 앱"
        }
    }
}

/// 실제로 띄우는 앱. `auto` 를 세션의 클라이언트로 풀어낸 결과라 여기엔 `auto` 가 없다.

/// 확장 크리스마스의 동작 시간. 이미지 제작과 웹 미리보기도 같은 설정을 사용한다.
enum Christmas16Timing {
    private struct Settings: Decodable {
        let cycle_seconds: [String: Double]
        let effect_periods: [String: Double]
        let frame_seconds: [String: [Double]]?
    }
    private static let values: Settings? = {
        guard let url = Bundle.main.url(forResource: "christmas-16-timing", withExtension: "json"),
              let data = try? Data(contentsOf: url),
              let decoded = try? JSONDecoder().decode(Settings.self, from: data) else { return nil }
        return decoded
    }()
    static func duration(row: Int) -> Double? { values?.cycle_seconds[String(row)] }
    static func effectPeriod(_ id: String) -> Double? { values?.effect_periods[id] }
    static func frameDurations(row: Int) -> [Double]? { values?.frame_seconds?[String(row)] }
    static func frameDuration(row: Int, frame: Int) -> Double? {
        guard let times = frameDurations(row: row), times.indices.contains(frame) else { return nil }
        return times[frame]
    }
}

/// 각 제스처의 변화 폭에 맞춰 재생한다. 다른 스킨의 시간은 유지한다.
func skinAnimation(_ animation: Animation, skin: PetSkin, columns: Int) -> Animation {
    // 두 리락쿠마 스킨의 생각 중 행은 6칸이고, 마지막 2칸은 투명하다.
    if (skin == .rilakkuma || skin == .rilakkumaCape), animation.row == 7 {
        return Animation(row: animation.row, frames: 6, interval: animation.interval,
                         cycleLimit: animation.cycleLimit, kicker: animation.kicker,
                         title: animation.title, tone: animation.tone)
    }
    if skin == .howl { return HowlSkin.animation(animation) }
    if skin == .jeanne { return JeanneSkin.animation(animation) }
    if skin == .pichiPitch { return PichiSkin.animation(animation) }
    if skin == .amuRan, columns == 16 { return AmuRanMotion.animation(animation) }
    if skin == .hana, columns == 16 { return HanaMotion.animation(animation) }
    guard skin == .christmas, columns == 16 else { return animation }
    return Animation(row: animation.row, frames: 16,
                     interval: (Christmas16Timing.duration(row: animation.row) ?? animation.interval * Double(animation.frames)) / 16,
                     cycleLimit: animation.cycleLimit, kicker: animation.kicker,
                     title: animation.title, tone: animation.tone)
}
