import AppKit
import Foundation

/// Approved HTML motion scenes and separate transparent effects, at the same source scale.
/// Pair scenes retain their sixteen independent cat drawings and articulated companions.
enum AmuApproved {
    struct Motion: Decodable { let cycle: Double; let samples: Int; let interval: Double; let drawings: Int }
    struct Manifest: Decodable { let cell: [Int]; let version: Int; let states: [String: Motion] }
    static let preference = "RettoAmuSeraMode"
    static var seraMode: Bool { UserDefaults.standard.bool(forKey: preference) }

    /// One choice per work/completion entry, owned by each RettoView.
    struct Choice {
        static let workingPool = ["heart","diamond","spade","clover"]
        static let completionPool = ["sera1","sera2"]
        private(set) var working = "spade"
        private(set) var completion = "sera1"
        private var token = ""
        private var lastTurn = ""
        static func group(_ state: PetState) -> String {
            switch state { case .running,.review:return "work";case .waving:return "complete";default:return state.rawValue }
        }
        @discardableResult mutating func enter(_ state: PetState, session: String, turn: String, pick: (Int)->Int = { Int.random(in:0..<$0) }) -> Bool {
            let group=Self.group(state),next=group+"|"+session
            if next == token {
                // Tool payloads may omit a turn id or enrich it after entry.
                if turn.isEmpty || lastTurn.isEmpty || turn == lastTurn {
                    if !turn.isEmpty { lastTurn=turn }
                    return false
                }
            }
            token=next;lastTurn=turn
            if group=="work" { working=Self.workingPool[pick(Self.workingPool.count)];return true }
            if group=="complete" { completion=Self.completionPool[pick(Self.completionPool.count)];return true }
            return false
        }
        mutating func preview(working:String?,completion:String?) {
            if let working,Self.workingPool.contains(working){self.working=working}
            if let completion,Self.completionPool.contains(completion){self.completion=completion}
        }
    }
    static func validateChoices() -> Bool {
        var seenWork=Set<String>(),seenComplete=Set<String>()
        for episode in 0..<64 {
            var c=Choice(),calls=0
            let picker:(Int)->Int={ n in calls+=1;return episode % n }
            guard c.enter(.running,session:"a",turn:"one",pick:picker) else{return false}
            let work=c.working;seenWork.insert(work)
            for s:PetState in [.running,.review,.running,.review] {
                guard !c.enter(s,session:"a",turn:"one",pick:picker),c.working==work else{return false}
            }
            guard !c.enter(.review,session:"a",turn:"",pick:picker),c.working==work else{return false}
            guard calls==1,c.enter(.waving,session:"a",turn:"one",pick:picker) else{return false}
            let done=c.completion;seenComplete.insert(done)
            for _ in 0..<100 {guard !c.enter(.waving,session:"a",turn:"one",pick:picker),c.completion==done else{return false}}
            guard calls==2 else{return false}
            _=c.enter(.idle,session:"a",turn:"one",pick:picker)
            guard c.enter(.running,session:"a",turn:"one",pick:picker),calls==3 else{return false}
            guard c.enter(.running,session:"b",turn:"one",pick:picker),calls==4 else{return false}
            guard c.enter(.running,session:"b",turn:"two",pick:picker),calls==5 else{return false}
        }
        guard seenWork==Set(Choice.workingPool),seenComplete==Set(Choice.completionPool) else{return false}
        print("PASS Amu choice: all4 working/all2 completion outcomes, stable repeated refresh/review alias, new episode/session redraws")
        return true
    }
    static let root = Bundle.main.resourceURL?.appendingPathComponent("AmuApproved")
    static let manifest: Manifest? = {
        guard let root, let data = try? Data(contentsOf: root.appendingPathComponent("manifest.json")) else { return nil }
        return try? JSONDecoder().decode(Manifest.self, from: data)
    }()
    static func key(row: Int, workingKey: String = "spade", completionKey: String = "sera1") -> String? {
        switch row {
        case 0: return "idle"
        case 3: return completionKey
        case 4: return seraMode ? "sera2" : "school"
        case 5: return "clover"
        case 6: return "diamond"
        case 7, 8: return workingKey
        case 11: return "sleep"
        default: return nil
        }
    }
    static let available: Bool = {
        guard let root, let m = manifest, m.cell == [448,640], m.states.count == 9 else { return false }
        for (key, motion) in m.states {
            guard motion.samples == 80, motion.cycle > 0 else { return false }
            for sample in 0..<80 {
                for layer in ["scene", "back", "front"] {
                    if !FileManager.default.fileExists(atPath: root.appendingPathComponent("\(key)-\(layer)-\(sample).png").path) { return false }
                }
            }
        }
        return true
    }()
    /// Display-only shadow anchor at the approved support line; never refit the art to costume bounds.
    static func shadowOffset(row: Int, in rect: NSRect, workingKey: String = "spade", completionKey: String = "sera1") -> CGFloat {
        guard let key = key(row:row,workingKey:workingKey,completionKey:completionKey) else { return 0 }
        let grounds: [String: CGFloat] = ["idle":585,"school":585,"heart":590,"diamond":590,"spade":590,"clover":590,"sera1":590,"sera2":590,"sleep":600]
        return rect.height * (628-(grounds[key] ?? 628))/640
    }
    private static let cache: NSCache<NSString, NSImage> = {
        let c = NSCache<NSString, NSImage>(); c.countLimit = 192; c.totalCostLimit = 112 * 1024 * 1024; return c
    }()
    static func sample(key: String, time: Double) -> Int {
        guard let m = manifest?.states[key], time.isFinite else { return 0 }
        return Int(floor(max(0,time).truncatingRemainder(dividingBy:m.cycle) / m.interval + 1e-7)) % m.samples
    }
    @discardableResult static func draw(row: Int, layer: String, time: Double, in rect: NSRect, workingKey: String = "spade", completionKey: String = "sera1") -> Bool {
        guard available, let key = key(row:row,workingKey:workingKey,completionKey:completionKey), let root else { return false }
        return draw(key:key, layer:layer, time:time, in:rect, root:root)
    }
    @discardableResult static func draw(key: String, layer: String, time: Double, in rect: NSRect, root: URL? = AmuApproved.root) -> Bool {
        guard let root else { return false }
        let name = "\(key)-\(layer)-\(sample(key:key,time:time))", token = name as NSString
        let image: NSImage
        if let cached = cache.object(forKey:token) { image = cached }
        else {
            guard let loaded = NSImage(contentsOf:root.appendingPathComponent(name+".png")) else { return false }
            image = loaded; cache.setObject(image,forKey:token,cost:448*640*4)
        }
        image.draw(in:rect,from:NSRect(origin:.zero,size:image.size),operation:.sourceOver,fraction:1,respectFlipped:false,hints:[.interpolation:NSImageInterpolation.high])
        return true
    }
    static func validate() -> Bool {
        guard available, let m = manifest, validateChoices() else { return false }
        for (key, motion) in m.states {
            guard abs(Double(motion.samples)*motion.interval-motion.cycle)<0.000001,
                  motion.drawings == (key == "idle" ? 1:16) else { return false }
            for i in 0...80 {
                guard sample(key:key,time:Double(i)*motion.interval) == i%80 else { return false }
            }
        }
        guard key(row:8)=="spade",key(row:7)=="spade",key(row:11)=="sleep",key(row:1)==nil else { return false }
        print("PASS Amu approved:8 full16-drawing motions + static school idle; exact80-sample clocks; sleep6.4s; legacy review maps to working; existing drag/gaze retained")
        return true
    }
}
